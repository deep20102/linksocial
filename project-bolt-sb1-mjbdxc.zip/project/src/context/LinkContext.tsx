import React, { createContext, useContext, useState } from 'react';
import { nanoid } from 'nanoid';

export interface Link {
  id: string;
  url: string;
  title: string;
  groupId?: string;
  clicks: number;
  logo?: File | null;
}

interface LinkContextType {
  links: Link[];
  groups: Group[];
  addLink: (link: Omit<Link, 'id' | 'clicks'>) => void;
  removeLink: (id: string) => void;
  updateLink: (id: string, link: Partial<Link>) => void;
  addGroup: (name: string) => void;
  removeGroup: (id: string) => void;
  reorderLinks: (newLinks: Link[]) => void;
}

export interface Group {
  id: string;
  name: string;
}

const LinkContext = createContext<LinkContextType | undefined>(undefined);

export function LinkProvider({ children }: { children: React.ReactNode }) {
  const [links, setLinks] = useState<Link[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);

  const addLink = (linkData: Omit<Link, 'id' | 'clicks'>) => {
    const newLink: Link = {
      id: nanoid(),
      clicks: 0,
      ...linkData,
    };
    setLinks((prev) => [...prev, newLink]);
  };

  const removeLink = (id: string) => {
    setLinks((prev) => prev.filter((link) => link.id !== id));
  };

  const updateLink = (id: string, updatedLink: Partial<Link>) => {
    setLinks((prev) =>
      prev.map((link) =>
        link.id === id ? { ...link, ...updatedLink } : link
      )
    );
  };

  const addGroup = (name: string) => {
    const newGroup: Group = {
      id: nanoid(),
      name,
    };
    setGroups((prev) => [...prev, newGroup]);
  };

  const removeGroup = (id: string) => {
    setGroups((prev) => prev.filter((group) => group.id !== id));
    // Remove group from links
    setLinks((prev) =>
      prev.map((link) =>
        link.groupId === id ? { ...link, groupId: undefined } : link
      )
    );
  };

  const reorderLinks = (newLinks: Link[]) => {
    setLinks(newLinks);
  };

  return (
    <LinkContext.Provider
      value={{
        links,
        groups,
        addLink,
        removeLink,
        updateLink,
        addGroup,
        removeGroup,
        reorderLinks,
      }}
    >
      {children}
    </LinkContext.Provider>
  );
}

export function useLinks() {
  const context = useContext(LinkContext);
  if (context === undefined) {
    throw new Error('useLinks must be used within a LinkProvider');
  }
  return context;
}