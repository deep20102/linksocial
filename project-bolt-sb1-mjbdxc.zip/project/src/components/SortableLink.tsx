import React, { forwardRef, useState, useCallback } from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { motion } from 'framer-motion';
import { Trash2, Edit3, BarChart2, GripVertical } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PasswordModal } from './PasswordModal';
import toast from 'react-hot-toast';

interface SortableLinkProps {
  link: {
    id: string;
    url: string;
    title: string;
    clicks: number;
    logo?: File | null;
    password?: string;
  };
  onEdit: () => void;
  onRemove: () => void;
}

export const SortableLink = forwardRef<HTMLDivElement, SortableLinkProps>(({ link, onEdit, onRemove }, ref) => {
  const navigate = useNavigate();
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: link.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 100 : 1,
  };

  const handleLinkClick = useCallback((e: React.MouseEvent) => {
    if (!(e.target as HTMLElement).closest('button')) {
      e.preventDefault();
      if (link.password) {
        setIsPasswordModalOpen(true);
      } else {
        window.open(link.url, '_blank');
      }
    }
  }, [link.password, link.url]);

  const handlePasswordSubmit = useCallback((password: string) => {
    if (password === link.password) {
      window.open(link.url, '_blank');
      setIsPasswordModalOpen(false);
    } else {
      toast.error('Incorrect password');
    }
  }, [link.password, link.url]);

  const handleModalClose = useCallback(() => {
    setIsPasswordModalOpen(false);
  }, []);

  return (
    <>
      <motion.div
        ref={setNodeRef}
        style={style}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ 
          type: "spring",
          stiffness: 500,
          damping: 30,
          mass: 1
        }}
        className={`group relative bg-white/10 backdrop-blur-md rounded-lg border border-white/20 transition-all hover:bg-white/20 cursor-pointer ${
          isDragging ? 'shadow-lg' : ''
        }`}
        onClick={handleLinkClick}
      >
        <div className="flex items-center space-x-3 px-4 py-3">
          <button
            {...attributes}
            {...listeners}
            className="p-1 rounded-lg hover:bg-white/10 text-white cursor-grab active:cursor-grabbing"
            onClick={(e) => e.stopPropagation()}
          >
            <GripVertical className="w-4 h-4" />
          </button>
          <div className="flex-shrink-0">
            {link.logo ? (
              <img
                src={URL.createObjectURL(link.logo)}
                alt={link.title}
                className="w-6 h-6 rounded"
              />
            ) : null}
          </div>
          <span className="font-medium text-white flex-grow">{link.title}</span>
          <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
              className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
              className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/analytics/${link.id}`);
              }}
              className="flex items-center space-x-1 px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm transition-colors"
            >
              <BarChart2 className="w-4 h-4" />
              <span>{link.clicks}</span>
            </button>
          </div>
        </div>
      </motion.div>

      <PasswordModal
        isOpen={isPasswordModalOpen}
        onClose={handleModalClose}
        onSubmit={handlePasswordSubmit}
      />
    </>
  );
});

SortableLink.displayName = 'SortableLink';