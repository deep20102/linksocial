import React from 'react';
import { Link as LinkIcon, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function EmptyLinkState() {
  const navigate = useNavigate();
  
  return (
    <div className="text-center py-12">
      <LinkIcon className="w-12 h-12 text-white/40 mx-auto mb-4" />
      <h3 className="text-lg font-medium text-white mb-2">
        No links added yet
      </h3>
      <p className="text-white/80 mb-4">
        Start adding your important links
      </p>
      <button
        onClick={() => navigate('/add-link')}
        className="inline-flex items-center px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50 transition-colors"
      >
        <Plus className="w-4 h-4 mr-2" />
        Add Your First Link
      </button>
    </div>
  );
}