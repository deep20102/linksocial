import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Input } from './forms/Input';
import { useLinks } from '../context/LinkContext';
import { CountrySelector } from './CountrySelector';
import toast from 'react-hot-toast';
import { Lock, Unlock, Trash2 } from 'lucide-react';

const linkSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  url: z.string().url('Please enter a valid URL'),
  groupId: z.string().optional(),
  password: z.string().optional(),
});

type LinkForm = z.infer<typeof linkSchema>;

interface EditLinkFormProps {
  linkId: string;
  onClose: () => void;
}

export function EditLinkForm({ linkId, onClose }: EditLinkFormProps) {
  const { links, updateLink, groups } = useLinks();
  const link = links.find(l => l.id === linkId);
  const [logo, setLogo] = useState<File | null>(link?.logo || null);
  const [isPasswordProtected, setIsPasswordProtected] = useState(!!link?.password);
  const [selectedCountries, setSelectedCountries] = useState<string[]>(
    link?.accessControl?.countries || []
  );
  const [accessMode, setAccessMode] = useState<'allow' | 'block'>(
    link?.accessControl?.mode || 'allow'
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<LinkForm>({
    resolver: zodResolver(linkSchema),
    defaultValues: {
      title: link?.title || '',
      url: link?.url || '',
      groupId: link?.groupId || '',
      password: link?.password || '',
    },
  });

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setLogo(file);
    }
  };

  const removeLogo = () => {
    setLogo(null);
  };

  const toggleCountry = (countryCode: string) => {
    setSelectedCountries(prev =>
      prev.includes(countryCode)
        ? prev.filter(code => code !== countryCode)
        : [...prev, countryCode]
    );
  };

  const onSubmit = async (data: LinkForm) => {
    try {
      await updateLink(linkId, {
        ...data,
        logo,
        password: isPasswordProtected ? data.password : undefined,
        accessControl: {
          mode: accessMode,
          countries: selectedCountries,
        },
      });
      toast.success('Link updated successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to update link');
    }
  };

  if (!link) {
    return null;
  }

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
      <h2 className="text-2xl font-bold text-white mb-6">Edit Link</h2>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <Input
          label="Link Title"
          name="title"
          placeholder="Enter link title"
          register={register}
          error={errors.title?.message}
        />

        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Logo
          </label>
          <div className="flex items-center space-x-4">
            {logo ? (
              <div className="relative">
                <img
                  src={URL.createObjectURL(logo)}
                  alt="Link logo"
                  className="w-12 h-12 rounded-lg"
                />
                <button
                  type="button"
                  onClick={removeLogo}
                  className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full text-white hover:bg-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <input
                type="file"
                accept="image/*"
                onChange={handleLogoChange}
                className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
              />
            )}
          </div>
        </div>

        <Input
          label="URL"
          name="url"
          placeholder="Enter link URL"
          register={register}
          error={errors.url?.message}
        />

        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Group
          </label>
          <select
            {...register('groupId')}
            className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
          >
            <option value="">No group</option>
            {groups.map((group) => (
              <option key={group.id} value={group.id}>
                {group.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <div className="flex items-center space-x-2 mb-2">
            <button
              type="button"
              onClick={() => setIsPasswordProtected(!isPasswordProtected)}
              className="text-white hover:text-purple-200"
            >
              {isPasswordProtected ? (
                <Lock className="w-5 h-5" />
              ) : (
                <Unlock className="w-5 h-5" />
              )}
            </button>
            <label className="text-sm font-medium text-white">
              Password Protection
            </label>
          </div>
          {isPasswordProtected && (
            <Input
              name="password"
              type="password"
              placeholder="Enter password to protect this link"
              register={register}
              error={errors.password?.message}
              showPasswordToggle
            />
          )}
        </div>

        <CountrySelector
          selectedCountries={selectedCountries}
          onCountryToggle={toggleCountry}
          mode={accessMode}
          onModeChange={setAccessMode}
        />

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50"
          >
            Save Changes
          </button>
        </div>
      </form>
    </div>
  );
}