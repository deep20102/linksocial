import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Lock, X } from 'lucide-react';
import { Input } from './forms/Input';

const passwordSchema = z.object({
  password: z.string().min(1, 'Password is required'),
});

type PasswordForm = z.infer<typeof passwordSchema>;

interface PasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (password: string) => void;
}

export const PasswordModal = React.memo(function PasswordModal({ 
  isOpen, 
  onClose, 
  onSubmit 
}: PasswordModalProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<PasswordForm>({
    resolver: zodResolver(passwordSchema),
  });

  const handleFormSubmit = (data: PasswordForm) => {
    onSubmit(data.password);
    reset();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 w-full max-w-md border border-white/20">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-2">
            <Lock className="w-5 h-5 text-white" />
            <h2 className="text-xl font-semibold text-white">Protected Link</h2>
          </div>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white"
            type="button"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <Input
            name="password"
            type="password"
            placeholder="Enter password to access this link"
            register={register}
            error={errors.password?.message}
            autoFocus
          />

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50"
            >
              Access Link
            </button>
          </div>
        </form>
      </div>
    </div>
  );
});