import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '../components/forms/Input';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

// Updated username regex to allow special chars at start/end
const USERNAME_REGEX = /^@[a-zA-Z0-9._\-'][a-zA-Z0-9._\-']*$/;

const signupSchema = z
  .object({
    username: z
      .string()
      .min(2, 'Username must start with @ and have at least one character')
      .max(20, 'Username cannot exceed 20 characters')
      .regex(USERNAME_REGEX, 'Username can only contain letters, numbers, and . _ - \'')
      .refine((val) => !val.includes(' '), 'Username cannot contain spaces'),
    email: z.string().email('Invalid email address'),
    password: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
      .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
      .regex(/[0-9]/, 'Password must contain at least one number')
      .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character'),
    confirmPassword: z.string(),
    acceptTerms: z.boolean().refine((val) => val === true, 'You must accept the terms and conditions'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ['confirmPassword'],
  });

type SignUpForm = z.infer<typeof signupSchema>;

// Mock registered emails - replace with actual API call
const registeredEmails = new Set(['test@example.com']);

export function SignUp() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [emailAvailable, setEmailAvailable] = useState<boolean | null>(null);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [checkingEmail, setCheckingEmail] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
    trigger,
  } = useForm<SignUpForm>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      username: '@',
    },
    mode: 'onChange',
  });

  const username = watch('username');
  const email = watch('email');
  const password = watch('password');
  const confirmPassword = watch('confirmPassword');

  // Ensure username always starts with @
  useEffect(() => {
    if (!username.startsWith('@')) {
      setValue('username', '@' + username.replace('@', ''));
    }
  }, [username, setValue]);

  // Check username availability
  useEffect(() => {
    const checkUsername = async () => {
      if (username.length > 1 && USERNAME_REGEX.test(username)) {
        setCheckingUsername(true);
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          setUsernameAvailable(true);
        } catch (error) {
          console.error('Failed to check username:', error);
        } finally {
          setCheckingUsername(false);
        }
      } else {
        setUsernameAvailable(null);
      }
    };

    const timeoutId = setTimeout(checkUsername, 500);
    return () => clearTimeout(timeoutId);
  }, [username]);

  // Check email availability
  useEffect(() => {
    const checkEmail = async () => {
      if (email && !errors.email) {
        setCheckingEmail(true);
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          setEmailAvailable(!registeredEmails.has(email));
        } catch (error) {
          console.error('Failed to check email:', error);
        } finally {
          setCheckingEmail(false);
        }
      } else {
        setEmailAvailable(null);
      }
    };

    const timeoutId = setTimeout(checkEmail, 500);
    return () => clearTimeout(timeoutId);
  }, [email, errors.email]);

  // Live password validation
  useEffect(() => {
    if (password || confirmPassword) {
      trigger(['password', 'confirmPassword']);
    }
  }, [password, confirmPassword, trigger]);

  const onSubmit = async (data: SignUpForm) => {
    if (!usernameAvailable || !emailAvailable) {
      toast.error('Username or email is not available');
      return;
    }

    try {
      await login(data.email, data.password);
      toast.success('Account created successfully!');
      navigate('/dashboard');
    } catch (error) {
      toast.error('Failed to create account');
    }
  };

  return (
    <div className="min-h-screen py-16 px-4">
      <div className="max-w-md mx-auto">
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Create Account</h1>
            <p className="text-white/80">Join LinkHub and share your content</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="relative">
              <Input
                name="username"
                placeholder="@username"
                register={register}
                error={errors.username?.message}
                autoComplete="username"
              />
              {username.length > 1 && !errors.username && (
                <div className="mt-1">
                  {checkingUsername ? (
                    <p className="text-sm text-white/80">Checking availability...</p>
                  ) : usernameAvailable ? (
                    <p className="text-sm text-green-400">Username is available</p>
                  ) : (
                    <p className="text-sm text-red-400">Username is not available</p>
                  )}
                </div>
              )}
            </div>

            <div className="relative">
              <Input
                name="email"
                type="email"
                placeholder="Email address"
                register={register}
                error={errors.email?.message}
                autoComplete="email"
              />
              {email && !errors.email && (
                <div className="mt-1">
                  {checkingEmail ? (
                    <p className="text-sm text-white/80">Checking email...</p>
                  ) : emailAvailable ? (
                    <p className="text-sm text-green-400">Email is available</p>
                  ) : (
                    <p className="text-sm text-red-400">Email is already registered</p>
                  )}
                </div>
              )}
            </div>

            <Input
              name="password"
              type="password"
              placeholder="Password"
              register={register}
              error={errors.password?.message}
              autoComplete="new-password"
              showPasswordToggle
            />

            <Input
              name="confirmPassword"
              type="password"
              placeholder="Confirm password"
              register={register}
              error={errors.confirmPassword?.message}
              autoComplete="new-password"
              showPasswordToggle
            />

            <div className="flex items-center">
              <input
                type="checkbox"
                id="acceptTerms"
                {...register('acceptTerms')}
                className="w-4 h-4 rounded border-white/20 bg-white/10 text-purple-600 focus:ring-purple-500"
              />
              <label htmlFor="acceptTerms" className="ml-2 text-sm text-white">
                I accept the{' '}
                <Link to="/terms" className="underline hover:text-purple-200">
                  Terms of Service
                </Link>{' '}
                and{' '}
                <Link to="/privacy" className="underline hover:text-purple-200">
                  Privacy Policy
                </Link>
              </label>
            </div>
            {errors.acceptTerms && (
              <p className="text-sm text-red-400">{errors.acceptTerms.message}</p>
            )}

            <button
              type="submit"
              disabled={isSubmitting || !usernameAvailable || !emailAvailable}
              className="w-full py-3 px-4 bg-white text-purple-600 rounded-lg font-medium hover:bg-purple-50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-purple-100 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Creating account...' : 'Create account'}
            </button>

            <p className="text-center text-white/80">
              Already have an account?{' '}
              <Link to="/login" className="text-white hover:text-purple-200">
                Sign in
              </Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}