import React from 'react';

interface AuthCardProps {
  children: React.ReactNode;
  title: string;
  subtitle: string;
}

export function AuthCard({ children, title, subtitle }: AuthCardProps) {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-8 bg-white/10 backdrop-blur-md p-8 rounded-xl border border-white/20">
        <div>
          <h2 className="text-3xl font-bold text-white text-center">{title}</h2>
          <p className="mt-2 text-center text-white/80">{subtitle}</p>
        </div>
        {children}
      </div>
    </div>
  );
}