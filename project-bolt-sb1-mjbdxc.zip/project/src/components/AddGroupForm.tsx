import React, { useState } from 'react';
import { Edit2, Trash2, Image as ImageIcon } from 'lucide-react';

interface AddGroupFormProps {
  newGroupName: string;
  onNameChange: (name: string) => void;
  onAdd: () => void;
  onCancel: () => void;
  isEditing?: boolean;
  groupLogo?: File | null;
  onLogoChange?: (logo: File | null) => void;
}

export function AddGroupForm({ 
  newGroupName, 
  onNameChange, 
  onAdd, 
  onCancel,
  isEditing = false,
  groupLogo,
  onLogoChange
}: AddGroupFormProps) {
  const [isEditingName, setIsEditingName] = useState(false);

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && onLogoChange) {
      onLogoChange(file);
    }
  };

  const removeLogo = () => {
    if (onLogoChange) {
      onLogoChange(null);
    }
  };

  return (
    <div className="mb-6 space-y-4">
      <div className="flex items-center space-x-4">
        {groupLogo ? (
          <div className="relative">
            <img
              src={URL.createObjectURL(groupLogo)}
              alt="Group logo"
              className="w-12 h-12 rounded-lg object-cover"
            />
            <button
              onClick={removeLogo}
              className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full text-white hover:bg-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="flex-shrink-0">
            <label className="block">
              <span className="sr-only">Choose group logo</span>
              <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center cursor-pointer hover:bg-white/20">
                <ImageIcon className="w-6 h-6 text-white" />
              </div>
              <input
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleLogoChange}
              />
            </label>
          </div>
        )}
        
        <div className="flex-1 flex items-center space-x-2">
          {isEditingName || !isEditing ? (
            <input
              type="text"
              value={newGroupName}
              onChange={(e) => onNameChange(e.target.value)}
              placeholder="Enter group name"
              className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          ) : (
            <div className="flex-1 flex items-center justify-between px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white">
              <span>{newGroupName}</span>
              <button
                onClick={() => setIsEditingName(true)}
                className="p-1 hover:bg-white/10 rounded"
              >
                <Edit2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="flex justify-end space-x-3">
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20"
        >
          Cancel
        </button>
        <button
          onClick={() => {
            onAdd();
            if (isEditing) {
              setIsEditingName(false);
            }
          }}
          className="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50"
        >
          {isEditing ? 'Save Changes' : 'Add Group'}
        </button>
      </div>
    </div>
  );
}