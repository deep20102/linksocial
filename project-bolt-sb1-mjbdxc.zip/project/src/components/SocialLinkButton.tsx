import React from 'react';
import {
  Facebook,
  Youtube,
  Instagram,
  Twitter,
  MessageCircle,
  Send,
  Ghost,
  Music2,
  MessagesSquare,
  Link as LinkIcon,
  Linkedin,
  Phone,
  Globe,
  MessageSquare,
  Share2,
  BookOpen,
  Gamepad2,
} from 'lucide-react';

export type SocialPlatform =
  | 'facebook'
  | 'youtube'
  | 'instagram'
  | 'twitter'
  | 'wechat'
  | 'telegram'
  | 'snapchat'
  | 'tiktok'
  | 'qq'
  | 'reddit'
  | 'pinterest'
  | 'quora'
  | 'discord'
  | 'tumblr'
  | 'linkedin'
  | 'viber'
  | 'custom';

interface SocialLinkButtonProps {
  platform: SocialPlatform;
  url: string;
  title: string;
  onClick?: () => void;
  className?: string;
}

const platformIcons: Record<SocialPlatform, React.ElementType> = {
  facebook: Facebook,
  youtube: Youtube,
  instagram: Instagram,
  twitter: Twitter,
  wechat: MessagesSquare,
  telegram: Send,
  snapchat: Ghost,
  tiktok: Music2,
  qq: MessageCircle,
  reddit: MessageSquare,
  pinterest: Share2,
  quora: BookOpen,
  discord: Gamepad2,
  tumblr: Globe,
  linkedin: Linkedin,
  viber: Phone,
  custom: LinkIcon,
};

const platformColors: Record<SocialPlatform, string> = {
  facebook: 'bg-[#1877F2] hover:bg-[#0E65D9]',
  youtube: 'bg-[#FF0000] hover:bg-[#D90000]',
  instagram: 'bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737]',
  twitter: 'bg-[#1DA1F2] hover:bg-[#0C85D0]',
  wechat: 'bg-[#7BB32E] hover:bg-[#6A9E28]',
  telegram: 'bg-[#0088CC] hover:bg-[#006BA3]',
  snapchat: 'bg-[#FFFC00] hover:bg-[#F7F500] text-black',
  tiktok: 'bg-[#000000] hover:bg-[#1A1A1A]',
  qq: 'bg-[#12B7F5] hover:bg-[#0FA2D9]',
  reddit: 'bg-[#FF4500] hover:bg-[#D93A00]',
  pinterest: 'bg-[#E60023] hover:bg-[#BD001D]',
  quora: 'bg-[#B92B27] hover:bg-[#991F1B]',
  discord: 'bg-[#7289DA] hover:bg-[#5B73BC]',
  tumblr: 'bg-[#35465C] hover:bg-[#2C3A4C]',
  linkedin: 'bg-[#0A66C2] hover:bg-[#084E96]',
  viber: 'bg-[#665CAC] hover:bg-[#524A8A]',
  custom: 'bg-gray-600 hover:bg-gray-700',
};

export function SocialLinkButton({ platform, url, title, onClick, className = '' }: SocialLinkButtonProps) {
  const Icon = platformIcons[platform];
  const colorClass = platformColors[platform];

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      onClick={onClick}
      className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-white transition-all ${colorClass} ${className}`}
    >
      <Icon className="w-5 h-5 flex-shrink-0" />
      <span className="font-medium flex-grow">{title}</span>
    </a>
  );
}