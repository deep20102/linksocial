import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Link as LinkIcon, LogOut, User } from 'lucide-react';

export function Layout() {
  const { isAuthenticated, logout } = useAuth();
  const location = useLocation();

  // Don't show header/footer on profile pages
  const isProfilePage = /^\/[^/]+$/.test(location.pathname) && 
    !['/login', '/signup', '/dashboard', '/pricing', '/about'].includes(location.pathname);
  
  if (isProfilePage) return <Outlet />;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500">
      <header className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-8">
              <Link to="/" className="flex items-center space-x-2">
                <LinkIcon className="w-8 h-8 text-white" />
                <span className="text-xl font-bold text-white">LinkHub</span>
              </Link>
              
              <div className="hidden md:flex items-center space-x-6">
                <Link to="/features" className="text-white hover:text-pink-200 transition">
                  Features
                </Link>
                <Link to="/pricing" className="text-white hover:text-pink-200 transition">
                  Pricing
                </Link>
                <Link to="/about" className="text-white hover:text-pink-200 transition">
                  About
                </Link>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <>
                  <Link to="/dashboard" className="text-white hover:text-pink-200 transition">
                    Dashboard
                  </Link>
                  <Link to="/edit-profile" className="text-white hover:text-pink-200 transition">
                    Edit Profile
                  </Link>
                  <button
                    onClick={logout}
                    className="flex items-center space-x-1 text-white hover:text-pink-200 transition"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/login"
                    className="text-white hover:text-pink-200 transition"
                  >
                    Login
                  </Link>
                  <Link
                    to="/signup"
                    className="bg-white text-purple-600 px-4 py-2 rounded-lg hover:bg-pink-100 transition"
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </div>
        </nav>
      </header>

      <main>
        <Outlet />
      </main>

      <footer className="bg-white/10 backdrop-blur-md border-t border-white/20 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <LinkIcon className="w-8 h-8 text-white" />
                <span className="text-xl font-bold text-white">LinkHub</span>
              </div>
              <p className="text-white/80 mb-4">
                Your all-in-one platform for managing and sharing your digital presence.
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Product</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/features" className="text-white/80 hover:text-white transition">
                    Features
                  </Link>
                </li>
                <li>
                  <Link to="/pricing" className="text-white/80 hover:text-white transition">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-white/80 hover:text-white transition">
                    About Us
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/privacy" className="text-white/80 hover:text-white transition">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link to="/terms" className="text-white/80 hover:text-white transition">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-white/20 text-center text-white/60">
            <p>&copy; {new Date().getFullYear()} LinkHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}