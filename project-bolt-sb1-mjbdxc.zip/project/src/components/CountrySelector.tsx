import React from 'react';
import { Globe } from 'lucide-react';

interface Country {
  code: string;
  name: string;
}

const countries: Country[] = [
  { code: 'US', name: 'United States' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'CA', name: 'Canada' },
  { code: 'AU', name: 'Australia' },
  { code: 'DE', name: 'Germany' },
  { code: 'FR', name: 'France' },
  { code: 'JP', name: 'Japan' },
  { code: 'IN', name: 'India' },
  // Add more countries as needed
];

interface CountrySelectorProps {
  selectedCountries: string[];
  onCountryToggle: (countryCode: string) => void;
  mode: 'allow' | 'block';
  onModeChange: (mode: 'allow' | 'block') => void;
}

export function CountrySelector({
  selectedCountries,
  onCountryToggle,
  mode,
  onModeChange,
}: CountrySelectorProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <label className="flex items-center space-x-2 text-white">
          <Globe className="w-5 h-5" />
          <span>Country Access Control</span>
        </label>
        <select
          value={mode}
          onChange={(e) => onModeChange(e.target.value as 'allow' | 'block')}
          className="bg-white/10 border border-white/20 rounded-lg text-white px-3 py-1"
        >
          <option value="allow">Allow List</option>
          <option value="block">Block List</option>
        </select>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {countries.map((country) => (
          <label
            key={country.code}
            className="flex items-center space-x-2 p-2 bg-white/10 rounded-lg cursor-pointer hover:bg-white/20"
          >
            <input
              type="checkbox"
              checked={selectedCountries.includes(country.code)}
              onChange={() => onCountryToggle(country.code)}
              className="rounded border-white/20 bg-white/10 text-purple-600 focus:ring-purple-500"
            />
            <span className="text-white text-sm">{country.name}</span>
          </label>
        ))}
      </div>
    </div>
  );
}