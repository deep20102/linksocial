import React from 'react';
import { Facebook, Youtube, Instagram, Twitter, MessageCircle, Send, Ghost, Music2, MessagesSquare, Linkedin, Phone } from 'lucide-react';

const platforms = [
  { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'bg-[#1877F2]' },
  { id: 'youtube', name: 'YouTube', icon: Youtube, color: 'bg-[#FF0000]' },
  { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'bg-[#E1306C]' },
  { id: 'twitter', name: 'Twitter', icon: Twitter, color: 'bg-[#1DA1F2]' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'bg-[#0A66C2]' },
  { id: 'telegram', name: 'Telegram', icon: Send, color: 'bg-[#0088cc]' },
  { id: 'snapchat', name: 'Snapchat', icon: Ghost, color: 'bg-[#FFFC00]' },
  { id: 'tiktok', name: 'TikTok', icon: Music2, color: 'bg-[#000000]' },
];

interface SocialPlatformSelectorProps {
  onSelect: (platform: string) => void;
}

export function SocialPlatformSelector({ onSelect }: SocialPlatformSelectorProps) {
  return (
    <div>
      <label className="block text-sm font-medium text-white mb-2">
        Quick Platform Select
      </label>
      <div className="grid grid-cols-4 gap-2">
        {platforms.map((platform) => {
          const Icon = platform.icon;
          return (
            <button
              key={platform.id}
              type="button"
              onClick={() => onSelect(platform.id)}
              className={`${platform.color} p-2 rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center`}
            >
              <Icon className="w-5 h-5 text-white" />
            </button>
          );
        })}
      </div>
    </div>
  );
}