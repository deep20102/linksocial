import React from 'react';
import { Folder, Trash2 } from 'lucide-react';

interface GroupButtonProps {
  id: string;
  name: string;
  isSelected: boolean;
  onSelect: () => void;
  onRemove: () => void;
}

export function GroupButton({ id, name, isSelected, onSelect, onRemove }: GroupButtonProps) {
  return (
    <div
      onClick={onSelect}
      className={`flex items-center px-4 py-2 rounded-lg transition-colors cursor-pointer ${
        isSelected
          ? 'bg-white text-purple-600'
          : 'bg-white/10 text-white hover:bg-white/20'
      }`}
    >
      <Folder className="w-4 h-4 mr-2" />
      <span>{name}</span>
      {isSelected && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="ml-2 p-1 hover:bg-white/10 rounded cursor-pointer"
        >
          <Trash2 className="w-3 h-3" />
        </div>
      )}
    </div>
  );
}