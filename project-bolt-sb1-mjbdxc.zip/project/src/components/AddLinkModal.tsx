import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Link as LinkIcon, Copy } from 'lucide-react';
import { Input } from './forms/Input';
import { SocialPlatform } from './SocialLinkButton';
import ShortUniqueId from 'short-unique-id';

const uid = new ShortUniqueId({ length: 8 });

const platforms: { id: SocialPlatform; name: string }[] = [
  { id: 'facebook', name: 'Facebook' },
  { id: 'youtube', name: 'YouTube' },
  { id: 'instagram', name: 'Instagram' },
  { id: 'tiktok', name: 'TikTok' },
  { id: 'wechat', name: 'WeChat' },
  { id: 'telegram', name: 'Telegram' },
  { id: 'snapchat', name: 'Snapchat' },
  { id: 'twitter', name: 'X (Twitter)' },
  { id: 'qq', name: 'QQ' },
  { id: 'reddit', name: 'Reddit' },
  { id: 'pinterest', name: 'Pinterest' },
  { id: 'quora', name: 'Quora' },
  { id: 'discord', name: 'Discord' },
  { id: 'tumblr', name: 'Tumblr' },
  { id: 'linkedin', name: 'LinkedIn' },
  { id: 'viber', name: 'Viber' },
];

const linkSchema = z.object({
  platform: z.string(),
  title: z.string().min(1, 'Title is required'),
  url: z.string().url('Please enter a valid URL'),
  groupId: z.string().optional(),
});

type LinkForm = z.infer<typeof linkSchema>;

interface AddLinkModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (link: { platform: SocialPlatform; url: string; title: string; groupId?: string }) => void;
  groups: Array<{ id: string; name: string }>;
}

export function AddLinkModal({ isOpen, onClose, onAdd, groups }: AddLinkModalProps) {
  const [selectedPlatform, setSelectedPlatform] = useState<SocialPlatform | ''>('');
  const [shortUrl, setShortUrl] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm<LinkForm>({
    resolver: zodResolver(linkSchema),
  });

  const url = watch('url');

  const generateShortUrl = () => {
    if (!url) return;
    const shortCode = uid();
    setShortUrl(`https://lnk.hub/${shortCode}`);
  };

  const copyShortUrl = async () => {
    if (!shortUrl) return;
    try {
      await navigator.clipboard.writeText(shortUrl);
      toast.success('Short URL copied to clipboard');
    } catch (error) {
      toast.error('Failed to copy URL');
    }
  };

  const onSubmit = (data: LinkForm) => {
    onAdd({
      platform: data.platform as SocialPlatform,
      url: shortUrl || data.url,
      title: data.title,
      groupId: data.groupId,
    });
    reset();
    setShortUrl('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Add Social Link</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Platform
            </label>
            <select
              {...register('platform')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              onChange={(e) => setSelectedPlatform(e.target.value as SocialPlatform)}
            >
              <option value="">Select a platform</option>
              {platforms.map((platform) => (
                <option key={platform.id} value={platform.id}>
                  {platform.name}
                </option>
              ))}
            </select>
            {errors.platform && (
              <p className="mt-1 text-sm text-red-600">{errors.platform.message}</p>
            )}
          </div>

          <Input
            name="title"
            label="Link Title"
            placeholder="Enter a title for your link"
            register={register}
            error={errors.title?.message}
          />

          <Input
            name="url"
            label="Profile URL"
            placeholder={`Enter your ${selectedPlatform} profile URL`}
            register={register}
            error={errors.url?.message}
          />

          {url && !errors.url && (
            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={generateShortUrl}
                className="text-purple-600 hover:text-purple-700 text-sm"
              >
                Generate Short URL
              </button>
              {shortUrl && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">{shortUrl}</span>
                  <button
                    type="button"
                    onClick={copyShortUrl}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Group (Optional)
            </label>
            <select
              {...register('groupId')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="">No group</option>
              {groups.map((group) => (
                <option key={group.id} value={group.id}>
                  {group.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-white bg-purple-600 rounded-lg hover:bg-purple-700"
            >
              Add Link
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}