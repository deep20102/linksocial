import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: number;
  Icon: LucideIcon;
}

export function StatsCard({ title, value, Icon }: StatsCardProps) {
  return (
    <div className="bg-white/10 rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-white">{title}</h3>
        <Icon className="w-6 h-6 text-white/60" />
      </div>
      <p className="text-3xl font-bold text-white">{value}</p>
    </div>
  );
}