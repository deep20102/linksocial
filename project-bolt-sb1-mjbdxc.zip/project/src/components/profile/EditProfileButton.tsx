import React from 'react';
import { Edit2 } from 'lucide-react';

interface EditProfileButtonProps {
  onClick: () => void;
}

export function EditProfileButton({ onClick }: EditProfileButtonProps) {
  return (
    <button
      onClick={onClick}
      className="absolute -bottom-3 left-1/2 -translate-x-1/2 px-4 py-2 bg-white text-purple-600 rounded-lg shadow-lg hover:bg-purple-50 transition-colors flex items-center space-x-2"
    >
      <Edit2 className="w-4 h-4" />
      <span>Edit Profile</span>
    </button>
  );
}