import React from 'react';
import { Mail, Phone, Globe } from 'lucide-react';

interface ContactInfo {
  email?: string;
  phone?: string;
  website?: string;
}

interface ContactInfoEditorProps {
  contact: ContactInfo;
  onContactChange: (contact: ContactInfo) => void;
  isPublic: boolean;
  onVisibilityChange: (isPublic: boolean) => void;
}

export function ContactInfoEditor({
  contact,
  onContactChange,
  isPublic,
  onVisibilityChange,
}: ContactInfoEditorProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Contact Information</h3>
      
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={isPublic}
            onChange={(e) => onVisibilityChange(e.target.checked)}
            className="rounded border-white/20 bg-white/10 text-purple-600 focus:ring-purple-500"
          />
          <label className="text-sm text-white">Make contact info public</label>
        </div>

        <div className="space-y-2">
          <label className="flex items-center space-x-2 text-sm font-medium text-white">
            <Mail className="w-4 h-4" />
            <span>Email</span>
          </label>
          <input
            type="email"
            value={contact.email || ''}
            onChange={(e) => onContactChange({ ...contact, email: e.target.value })}
            placeholder="your@email.com"
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center space-x-2 text-sm font-medium text-white">
            <Phone className="w-4 h-4" />
            <span>Phone</span>
          </label>
          <input
            type="tel"
            value={contact.phone || ''}
            onChange={(e) => onContactChange({ ...contact, phone: e.target.value })}
            placeholder="+1 (555) 123-4567"
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center space-x-2 text-sm font-medium text-white">
            <Globe className="w-4 h-4" />
            <span>Website</span>
          </label>
          <input
            type="url"
            value={contact.website || ''}
            onChange={(e) => onContactChange({ ...contact, website: e.target.value })}
            placeholder="https://yourwebsite.com"
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
          />
        </div>
      </div>
    </div>
  );
}