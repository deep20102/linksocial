import React from 'react';
import { Eye, EyeOff, Lock } from 'lucide-react';

interface PrivacySettings {
  isProfilePublic: boolean;
  showEmail: boolean;
  showLocation: boolean;
  allowIndexing: boolean;
}

interface PrivacySettingsProps {
  settings: PrivacySettings;
  onSettingsChange: (settings: PrivacySettings) => void;
}

export function PrivacySettings({ settings, onSettingsChange }: PrivacySettingsProps) {
  const toggleSetting = (key: keyof PrivacySettings) => {
    onSettingsChange({
      ...settings,
      [key]: !settings[key],
    });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white flex items-center">
        <Lock className="w-5 h-5 mr-2" />
        Privacy Settings
      </h3>

      <div className="space-y-3">
        <div className="flex items-center justify-between px-4 py-3 bg-white/10 rounded-lg">
          <div className="flex items-center">
            {settings.isProfilePublic ? (
              <Eye className="w-5 h-5 mr-2 text-white" />
            ) : (
              <EyeOff className="w-5 h-5 mr-2 text-white" />
            )}
            <span className="text-white">Public Profile</span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.isProfilePublic}
              onChange={() => toggleSetting('isProfilePublic')}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-white/20 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
          </label>
        </div>

        <div className="flex items-center justify-between px-4 py-3 bg-white/10 rounded-lg">
          <span className="text-white">Show Email</span>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.showEmail}
              onChange={() => toggleSetting('showEmail')}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-white/20 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
          </label>
        </div>

        <div className="flex items-center justify-between px-4 py-3 bg-white/10 rounded-lg">
          <span className="text-white">Show Location</span>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.showLocation}
              onChange={() => toggleSetting('showLocation')}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-white/20 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
          </label>
        </div>

        <div className="flex items-center justify-between px-4 py-3 bg-white/10 rounded-lg">
          <span className="text-white">Allow Search Engines</span>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.allowIndexing}
              onChange={() => toggleSetting('allowIndexing')}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-white/20 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
          </label>
        </div>
      </div>
    </div>
  );
}