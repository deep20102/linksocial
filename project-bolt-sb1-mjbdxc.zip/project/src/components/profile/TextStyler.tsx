import React, { useState } from 'react';
import { Type } from 'lucide-react';
import { HexColorPicker } from 'react-colorful';
import { fontFamilies } from '../../utils/fonts';
import { textColors } from '../../utils/colors';
import { TextStyle } from '../../types/theme';

interface TextStylerProps {
  style: TextStyle;
  onStyleChange: (style: TextStyle) => void;
}

export function TextStyler({ style, onStyleChange }: TextStylerProps) {
  const [showColorPicker, setShowColorPicker] = useState(false);

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white flex items-center">
        <Type className="w-5 h-5 mr-2" />
        Text Style
      </h3>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Font Family
          </label>
          <div className="grid grid-cols-2 gap-2">
            {fontFamilies.map((font) => (
              <button
                key={font.id}
                onClick={() => onStyleChange({ ...style, fontFamily: font.id })}
                className={`px-4 py-3 rounded-lg ${
                  style.fontFamily === font.id
                    ? 'bg-white text-purple-600'
                    : 'bg-white/10 text-white hover:bg-white/20'
                } ${font.class}`}
              >
                <span className="block text-sm">{font.name}</span>
                <span className="block text-xs opacity-60">{font.preview}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Text Color
          </label>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              {textColors.map((color) => (
                <button
                  key={color.id}
                  onClick={() => onStyleChange({ ...style, color: color.value })}
                  className={`h-10 rounded-lg border-2 transition ${
                    style.color === color.value
                      ? 'border-white scale-105'
                      : 'border-transparent hover:border-white/50'
                  }`}
                  style={{ backgroundColor: color.value }}
                >
                  <span className="sr-only">{color.name}</span>
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowColorPicker(!showColorPicker)}
                className="w-10 h-10 rounded-lg border-2 border-white/20"
                style={{ backgroundColor: style.color }}
              />
              <input
                type="text"
                value={style.color}
                onChange={(e) => onStyleChange({ ...style, color: e.target.value })}
                placeholder="#FFFFFF"
                className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
              />
            </div>

            {showColorPicker && (
              <div className="mt-2">
                <HexColorPicker
                  color={style.color}
                  onChange={(color) => onStyleChange({ ...style, color })}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}