import React, { useState, useEffect } from 'react';
import { MapPin } from 'lucide-react';
import { useDebounce } from '../../hooks/useDebounce';

interface Location {
  id: string;
  name: string;
  country: string;
}

interface LocationInputProps {
  location: string;
  onLocationChange: (location: string) => void;
}

export function LocationInput({ location, onLocationChange }: LocationInputProps) {
  const [searchTerm, setSearchTerm] = useState(location);
  const [suggestions, setSuggestions] = useState<Location[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const debouncedSearch = useDebounce(searchTerm, 300);

  useEffect(() => {
    const searchLocations = async () => {
      if (debouncedSearch.length < 2) {
        setSuggestions([]);
        return;
      }

      try {
        // Simulated API call - replace with actual location search API
        const mockSuggestions: Location[] = [
          { id: '1', name: 'San Francisco', country: 'USA' },
          { id: '2', name: 'San Diego', country: 'USA' },
          { id: '3', name: 'San Jose', country: 'USA' },
        ].filter(loc => 
          loc.name.toLowerCase().includes(debouncedSearch.toLowerCase())
        );

        setSuggestions(mockSuggestions);
        setShowSuggestions(true);
      } catch (error) {
        console.error('Failed to fetch locations:', error);
      }
    };

    searchLocations();
  }, [debouncedSearch]);

  const handleLocationSelect = (location: Location) => {
    const fullLocation = `${location.name}, ${location.country}`;
    setSearchTerm(fullLocation);
    onLocationChange(fullLocation);
    setShowSuggestions(false);
  };

  return (
    <div className="relative">
      <label className="block text-sm font-medium text-white mb-2">
        <div className="flex items-center space-x-2">
          <MapPin className="w-4 h-4" />
          <span>Location</span>
        </div>
      </label>
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        onFocus={() => setShowSuggestions(true)}
        placeholder="Search for a location..."
        className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
      />
      
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-10 w-full mt-1 bg-white/10 backdrop-blur-md border border-white/20 rounded-lg shadow-lg">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion.id}
              onClick={() => handleLocationSelect(suggestion)}
              className="w-full px-4 py-2 text-left text-white hover:bg-white/10 first:rounded-t-lg last:rounded-b-lg"
            >
              {suggestion.name}, {suggestion.country}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}