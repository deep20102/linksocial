import React from 'react';
import { QrCode, Copy, Share2 } from 'lucide-react';
import toast from 'react-hot-toast';

interface ProfileQRCodeProps {
  username: string;
  qrCodeUrl: string;
}

export function ProfileQRCode({ username, qrCodeUrl }: ProfileQRCodeProps) {
  const profileUrl = `linkhub.com/@${username}`;

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(profileUrl);
      toast.success('Profile URL copied to clipboard');
    } catch (error) {
      toast.error('Failed to copy URL');
    }
  };

  const shareProfile = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `${username}'s LinkHub Profile`,
          url: profileUrl,
        });
      } else {
        await copyToClipboard();
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  return (
    <div className="space-y-6 text-center">
      <div className="space-y-2">
        <h3 className="text-lg font-semibold text-white flex items-center justify-center">
          <QrCode className="w-5 h-5 mr-2" />
          Share Your Profile
        </h3>
        <div className="flex items-center justify-center space-x-2">
          <span className="text-white/80">{profileUrl}</span>
          <button
            onClick={copyToClipboard}
            className="p-1 hover:bg-white/10 rounded"
          >
            <Copy className="w-4 h-4 text-white" />
          </button>
          <button
            onClick={shareProfile}
            className="p-1 hover:bg-white/10 rounded"
          >
            <Share2 className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>

      <div className="flex justify-center">
        <img
          src={qrCodeUrl}
          alt="Profile QR Code"
          className="w-48 h-48 bg-white p-2 rounded-lg"
        />
      </div>

      <p className="text-white/60 text-sm">
        Scan this QR code to visit my profile
      </p>
    </div>
  );
}