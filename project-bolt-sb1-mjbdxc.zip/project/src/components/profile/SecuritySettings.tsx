import React, { useState } from 'react';
import { Lock, Key, Shield, UserX } from 'lucide-react';
import { Input } from '../forms/Input';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';

const passwordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number')
    .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character'),
  confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type PasswordForm = z.infer<typeof passwordSchema>;

interface SecuritySettingsProps {
  onDeactivate: () => void;
  onDelete: () => void;
}

export function SecuritySettings({ onDeactivate, onDelete }: SecuritySettingsProps) {
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<PasswordForm>({
    resolver: zodResolver(passwordSchema),
  });

  const onPasswordSubmit = async (data: PasswordForm) => {
    try {
      // Here you would typically call an API to update the password
      toast.success('Password updated successfully');
      setShowPasswordForm(false);
      reset();
    } catch (error) {
      toast.error('Failed to update password');
    }
  };

  const handleDeactivate = () => {
    if (window.confirm('Are you sure you want to deactivate your account?')) {
      onDeactivate();
    }
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to permanently delete your account? This action cannot be undone.')) {
      onDelete();
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-white flex items-center">
        <Shield className="w-5 h-5 mr-2" />
        Security Settings
      </h3>

      <div className="space-y-4">
        <button
          onClick={() => setShowPasswordForm(!showPasswordForm)}
          className="w-full flex items-center justify-between px-4 py-3 bg-white/10 rounded-lg text-white hover:bg-white/20"
        >
          <div className="flex items-center">
            <Key className="w-5 h-5 mr-2" />
            <span>Change Password</span>
          </div>
        </button>

        {showPasswordForm && (
          <form onSubmit={handleSubmit(onPasswordSubmit)} className="space-y-4">
            <Input
              name="currentPassword"
              type="password"
              placeholder="Current Password"
              register={register}
              error={errors.currentPassword?.message}
              showPasswordToggle
            />
            <Input
              name="newPassword"
              type="password"
              placeholder="New Password"
              register={register}
              error={errors.newPassword?.message}
              showPasswordToggle
            />
            <Input
              name="confirmPassword"
              type="password"
              placeholder="Confirm New Password"
              register={register}
              error={errors.confirmPassword?.message}
              showPasswordToggle
            />
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowPasswordForm(false)}
                className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50"
              >
                Update Password
              </button>
            </div>
          </form>
        )}

        <div className="flex items-center justify-between px-4 py-3 bg-white/10 rounded-lg">
          <div className="flex items-center">
            <Lock className="w-5 h-5 mr-2 text-white" />
            <span className="text-white">Two-Factor Authentication</span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={twoFactorEnabled}
              onChange={(e) => setTwoFactorEnabled(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-white/20 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
          </label>
        </div>

        <div className="space-y-3">
          <button
            onClick={handleDeactivate}
            className="w-full flex items-center justify-between px-4 py-3 bg-orange-500/10 text-orange-500 rounded-lg hover:bg-orange-500/20"
          >
            <span>Deactivate Account</span>
            <UserX className="w-5 h-5" />
          </button>

          <button
            onClick={handleDelete}
            className="w-full flex items-center justify-between px-4 py-3 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500/20"
          >
            <span>Delete Account Permanently</span>
            <UserX className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}