import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';

export function ProfileFooter() {
  return (
    <footer className="py-8 text-center">
      <div className="flex items-center justify-center space-x-1 text-white/60">
        <span>Made with</span>
        <Heart className="w-4 h-4 text-red-500" />
        <span>by</span>
        <Link to="/" className="hover:text-white transition">
          LinkHub
        </Link>
      </div>
    </footer>
  );
}