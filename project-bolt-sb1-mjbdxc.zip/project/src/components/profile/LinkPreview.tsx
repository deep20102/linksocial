import React from 'react';
import { ExternalLink, Layout, Grid, List, Columns, Table } from 'lucide-react';

interface LinkPreviewProps {
  links: Array<{
    id: string;
    title: string;
    url: string;
    platform?: string;
  }>;
  layout: 'grid' | 'list' | 'masonry' | 'table';
  onLayoutChange: (layout: 'grid' | 'list' | 'masonry' | 'table') => void;
}

export function LinkPreview({ links, layout, onLayoutChange }: LinkPreviewProps) {
  const layouts = [
    { id: 'grid', icon: Grid, label: 'Grid' },
    { id: 'list', icon: List, label: 'List' },
    { id: 'masonry', icon: Columns, label: 'Masonry' },
    { id: 'table', icon: Table, label: 'Table' }
  ];

  const getLayoutClasses = () => {
    switch (layout) {
      case 'grid':
        return 'grid grid-cols-2 gap-4';
      case 'masonry':
        return 'columns-2 gap-4';
      case 'table':
        return 'table w-full';
      default:
        return 'space-y-4';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Layout className="w-5 h-5 mr-2" />
          Link Layout
        </h3>
        <div className="flex space-x-2">
          {layouts.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => onLayoutChange(id as any)}
              className={`p-2 rounded-lg ${
                layout === id
                  ? 'bg-white text-purple-600'
                  : 'bg-white/10 text-white hover:bg-white/20'
              }`}
              title={label}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>
      </div>

      {layout === 'table' ? (
        <div className="bg-white/10 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/20">
                <th className="px-4 py-3 text-left text-sm font-medium text-white">Title</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-white">URL</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-white">Platform</th>
              </tr>
            </thead>
            <tbody>
              {links.map((link) => (
                <tr key={link.id} className="border-b border-white/10 last:border-0">
                  <td className="px-4 py-3 text-white">{link.title}</td>
                  <td className="px-4 py-3 text-white/80">{link.url}</td>
                  <td className="px-4 py-3 text-white/80">{link.platform || 'Custom'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className={getLayoutClasses()}>
          {links.map((link) => (
            <a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-4 text-white hover:bg-white/20 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="font-medium">{link.title}</span>
                <ExternalLink className="w-4 h-4 opacity-60" />
              </div>
              {layout !== 'grid' && (
                <p className="mt-2 text-sm text-white/60">{link.url}</p>
              )}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}