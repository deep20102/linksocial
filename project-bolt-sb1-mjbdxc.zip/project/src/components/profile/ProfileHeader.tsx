import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export function ProfileHeader() {
  return (
    <header className="bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="text-white hover:text-purple-200 transition">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex items-center space-x-4">
            <Link
              to="/edit-profile"
              className="text-white hover:text-purple-200 transition"
            >
              Edit Profile
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}