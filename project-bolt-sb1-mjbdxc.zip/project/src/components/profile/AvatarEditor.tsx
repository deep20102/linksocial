import React from 'react';
import { Camera, Crop, Maximize2, Minimize2 } from 'lucide-react';

interface AvatarEditorProps {
  avatar: string;
  shape: 'circle' | 'square' | 'rectangle';
  size: { width: number; height: number };
  onShapeChange: (shape: 'circle' | 'square' | 'rectangle') => void;
  onSizeChange: (size: { width: number; height: number }) => void;
  onImageChange: (file: File) => void;
}

export function AvatarEditor({
  avatar,
  shape,
  size,
  onShapeChange,
  onSizeChange,
  onImageChange,
}: AvatarEditorProps) {
  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onImageChange(file);
    }
  };

  const getShapeClass = () => {
    switch (shape) {
      case 'circle':
        return 'rounded-full';
      case 'square':
        return 'rounded-lg';
      case 'rectangle':
        return 'rounded-lg';
      default:
        return 'rounded-full';
    }
  };

  return (
    <div className="space-y-4">
      <div className="relative mx-auto" style={{ width: size.width, height: size.height }}>
        <img
          src={avatar}
          alt="Profile"
          className={`w-full h-full object-cover ${getShapeClass()}`}
        />
        <label className="absolute bottom-0 right-0 p-2 bg-purple-600 rounded-full cursor-pointer hover:bg-purple-700 transition">
          <Camera className="w-4 h-4 text-white" />
          <input
            type="file"
            className="hidden"
            accept="image/*"
            onChange={handleImageChange}
          />
        </label>
      </div>

      <div className="flex justify-center space-x-4">
        <button
          onClick={() => onShapeChange('circle')}
          className={`p-2 rounded-full ${
            shape === 'circle' ? 'bg-white text-purple-600' : 'bg-white/10 text-white'
          }`}
        >
          <div className="w-6 h-6 rounded-full border-2 border-current" />
        </button>
        <button
          onClick={() => onShapeChange('square')}
          className={`p-2 rounded-lg ${
            shape === 'square' ? 'bg-white text-purple-600' : 'bg-white/10 text-white'
          }`}
        >
          <div className="w-6 h-6 rounded-lg border-2 border-current" />
        </button>
        <button
          onClick={() => onShapeChange('rectangle')}
          className={`p-2 rounded-lg ${
            shape === 'rectangle' ? 'bg-white text-purple-600' : 'bg-white/10 text-white'
          }`}
        >
          <div className="w-8 h-6 rounded-lg border-2 border-current" />
        </button>
      </div>

      <div className="flex items-center space-x-4">
        <label className="text-white text-sm">Size:</label>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onSizeChange({ width: size.width - 10, height: size.height - 10 })}
            className="p-1 bg-white/10 rounded hover:bg-white/20"
          >
            <Minimize2 className="w-4 h-4 text-white" />
          </button>
          <button
            onClick={() => onSizeChange({ width: size.width + 10, height: size.height + 10 })}
            className="p-1 bg-white/10 rounded hover:bg-white/20"
          >
            <Maximize2 className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-white mb-1">Width (px)</label>
          <input
            type="number"
            value={size.width}
            onChange={(e) => onSizeChange({ ...size, width: parseInt(e.target.value) || 100 })}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
            min="50"
            max="500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white mb-1">Height (px)</label>
          <input
            type="number"
            value={size.height}
            onChange={(e) => onSizeChange({ ...size, height: parseInt(e.target.value) || 100 })}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
            min="50"
            max="500"
          />
        </div>
      </div>
    </div>
  );
}