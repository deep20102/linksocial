import React, { useState } from 'react';
import { Palette, Upload, Trash2 } from 'lucide-react';
import { HexColorPicker } from 'react-colorful';
import { themes } from '../../utils/themes';
import { BackgroundConfig } from '../../types/theme';

interface ThemeSelectorProps {
  selectedTheme: string;
  onThemeChange: (themeId: string) => void;
  customBackground?: string;
  onCustomBackgroundChange: (background: string) => void;
  customColor: string;
  onCustomColorChange: (color: string) => void;
}

export function ThemeSelector({
  selectedTheme,
  onThemeChange,
  customBackground = '',
  onCustomBackgroundChange,
  customColor,
  onCustomColorChange
}: ThemeSelectorProps) {
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [bgSize, setBgSize] = useState<BackgroundConfig['size']>('cover');
  const [colorInputValue, setColorInputValue] = useState(customColor);

  const handleColorInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setColorInputValue(newValue);
    // Only update parent state if the value is a valid hex color
    if (/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(newValue)) {
      onCustomColorChange(newValue);
    }
  };

  const handleColorPickerChange = (color: string) => {
    setColorInputValue(color);
    onCustomColorChange(color);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onCustomBackgroundChange(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-white flex items-center">
        <Palette className="w-5 h-5 mr-2" />
        Choose Theme
      </h3>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {themes.map((theme) => (
          <button
            key={theme.id}
            onClick={() => onThemeChange(theme.id)}
            className={`h-20 rounded-lg ${theme.background} p-1 transition ${
              selectedTheme === theme.id ? 'ring-2 ring-white' : 'opacity-70 hover:opacity-100'
            }`}
          >
            <div className="h-full w-full rounded bg-white/10 backdrop-blur-sm flex items-center justify-center">
              <span className={`font-medium ${theme.textColor}`}>{theme.name}</span>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Custom Color
          </label>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowColorPicker(!showColorPicker)}
              className="w-10 h-10 rounded-lg border-2 border-white/20"
              style={{ backgroundColor: colorInputValue }}
            />
            <input
              type="text"
              value={colorInputValue}
              onChange={handleColorInputChange}
              placeholder="#000000"
              className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
            />
          </div>
          {showColorPicker && (
            <div className="mt-2">
              <HexColorPicker color={customColor} onChange={handleColorPickerChange} />
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Custom Background Image
          </label>
          <div className="space-y-4">
            {!customBackground && (
              <label className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white hover:bg-white/20 cursor-pointer block">
                <div className="flex items-center justify-center space-x-2">
                  <Upload className="w-4 h-4" />
                  <span>Choose Image</span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            )}

            {customBackground && (
              <div className="space-y-4">
                <div className="relative">
                  <img
                    src={customBackground}
                    alt="Custom background"
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <button
                    onClick={() => onCustomBackgroundChange('')}
                    className="absolute top-2 right-2 p-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500/20"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-white">
                    Background Size
                  </label>
                  <select
                    value={bgSize}
                    onChange={(e) => setBgSize(e.target.value as BackgroundConfig['size'])}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  >
                    <option value="cover">Cover</option>
                    <option value="contain">Contain</option>
                    <option value="auto">Auto</option>
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}