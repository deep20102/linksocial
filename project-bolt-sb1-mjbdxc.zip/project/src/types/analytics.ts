export type DeviceType = 'mobile' | 'desktop';
export type BrowserType = 'chrome' | 'firefox' | 'safari';

export interface CountryStats {
  name: string;
  clicks: number;
}

export interface AnalyticsData {
  totalClicks: number;
  todayClicks: number;
  averageClicksPerDay: number;
  devices: Record<DeviceType, number>;
  browsers: Record<BrowserType, number>;
  countries: CountryStats[];
}