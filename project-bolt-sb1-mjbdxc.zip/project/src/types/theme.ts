export interface Theme {
  id: string;
  name: string;
  background: string;
  textColor: string;
}

export interface TextStyle {
  fontFamily: string;
  color: string;
}

export interface BackgroundConfig {
  type: 'theme' | 'color' | 'image';
  value: string;
  size?: 'cover' | 'contain' | 'auto';
}

export interface ThemeConfig {
  id: string;
  name: string;
  background: string;
  textColor: string;
  preview?: string;
}