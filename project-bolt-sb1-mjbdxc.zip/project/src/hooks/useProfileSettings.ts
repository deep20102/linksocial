import { useState } from 'react';
import { TextStyle } from '../types/theme';

interface ProfileSettings {
  avatar: {
    file: File | null;
    shape: 'circle' | 'square' | 'rectangle';
    size: { width: number; height: number };
  };
  theme: {
    id: string;
    color: string;
    background: string;
  };
  textStyle: TextStyle;
  location: string;
  contact: {
    email?: string;
    phone?: string;
    website?: string;
  };
  privacy: {
    isProfilePublic: boolean;
    showContact: boolean;
    showLocation: boolean;
    allowIndexing: boolean;
  };
  links: Array<{
    id: string;
    title: string;
    url: string;
    platform?: string;
  }>;
  layout: 'grid' | 'list' | 'masonry' | 'table';
}

export function useProfileSettings() {
  const [settings, setSettings] = useState<ProfileSettings>({
    avatar: {
      file: null,
      shape: 'circle',
      size: { width: 150, height: 150 },
    },
    theme: {
      id: 'gradient-1',
      color: '#FFFFFF',
      background: '',
    },
    textStyle: {
      fontFamily: 'sans',
      color: '#FFFFFF',
    },
    location: '',
    contact: {},
    privacy: {
      isProfilePublic: true,
      showContact: false,
      showLocation: true,
      allowIndexing: true,
    },
    links: [],
    layout: 'grid',
  });

  const updateAvatar = (avatar: typeof settings.avatar) => {
    setSettings((prev) => ({ ...prev, avatar }));
  };

  const updateTheme = (theme: typeof settings.theme) => {
    setSettings((prev) => ({ ...prev, theme }));
  };

  const updateTextStyle = (textStyle: TextStyle) => {
    setSettings((prev) => ({ ...prev, textStyle }));
  };

  const updateLocation = (location: string) => {
    setSettings((prev) => ({ ...prev, location }));
  };

  const updateContact = (contact: typeof settings.contact) => {
    setSettings((prev) => ({ ...prev, contact }));
  };

  const updatePrivacy = (privacy: typeof settings.privacy) => {
    setSettings((prev) => ({ ...prev, privacy }));
  };

  const updateLayout = (layout: typeof settings.layout) => {
    setSettings((prev) => ({ ...prev, layout }));
  };

  return {
    ...settings,
    updateAvatar,
    updateTheme,
    updateTextStyle,
    updateLocation,
    updateContact,
    updatePrivacy,
    updateLayout,
  };
}