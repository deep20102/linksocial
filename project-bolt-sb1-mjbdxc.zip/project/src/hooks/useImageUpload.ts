import { useState } from 'react';

interface UseImageUploadOptions {
  maxSize?: number; // in bytes
  acceptedTypes?: string[];
}

export function useImageUpload(options: UseImageUploadOptions = {}) {
  const [imageUrl, setImageUrl] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleImageUpload = (file: File) => {
    setError('');

    if (options.maxSize && file.size > options.maxSize) {
      setError(`File size must be less than ${options.maxSize / 1024 / 1024}MB`);
      return;
    }

    if (options.acceptedTypes && !options.acceptedTypes.includes(file.type)) {
      setError('Invalid file type');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setImageUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const clearImage = () => {
    setImageUrl('');
    setError('');
  };

  return {
    imageUrl,
    error,
    handleImageUpload,
    clearImage
  };
}