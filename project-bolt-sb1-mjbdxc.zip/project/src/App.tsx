import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { SignUp } from './pages/SignUp';
import { Dashboard } from './pages/Dashboard';
import { Profile } from './pages/Profile';
import { Pricing } from './pages/Pricing';
import { NotFound } from './pages/NotFound';
import { About } from './pages/About';
import { ForgotPassword } from './pages/ForgotPassword';
import { AddLink } from './pages/AddLink';
import { Analytics } from './pages/Analytics';
import { AuthProvider } from './context/AuthContext';
import { LinkProvider } from './context/LinkContext';
import { Toaster } from 'react-hot-toast';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <LinkProvider>
          <Toaster position="top-right" />
          <Routes>
            <Route element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="login" element={<Login />} />
              <Route path="signup" element={<SignUp />} />
              <Route path="forgot-password" element={<ForgotPassword />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="add-link" element={<AddLink />} />
              <Route path="analytics/:id" element={<Analytics />} />
              <Route path="pricing" element={<Pricing />} />
              <Route path="about" element={<About />} />
              <Route path=":username" element={<Profile />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </LinkProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;