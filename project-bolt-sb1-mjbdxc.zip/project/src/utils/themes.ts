import { ThemeConfig } from '../types/theme';

export const themes: ThemeConfig[] = [
  {
    id: 'gradient-1',
    name: 'Purple Sunset',
    background: 'bg-gradient-to-br from-purple-600 via-pink-500 to-red-500',
    textColor: 'text-white',
    preview: 'Vibrant & Modern'
  },
  {
    id: 'gradient-2',
    name: 'Ocean Breeze',
    background: 'bg-gradient-to-br from-blue-500 via-teal-400 to-emerald-500',
    textColor: 'text-white',
    preview: 'Fresh & Calm'
  },
  {
    id: 'gradient-3',
    name: 'Golden Hour',
    background: 'bg-gradient-to-br from-amber-500 via-orange-500 to-red-500',
    textColor: 'text-white',
    preview: 'Warm & Inviting'
  },
  {
    id: 'gradient-4',
    name: 'Northern Lights',
    background: 'bg-gradient-to-br from-green-400 via-cyan-500 to-blue-500',
    textColor: 'text-white',
    preview: 'Ethereal & Dreamy'
  },
  {
    id: 'gradient-5',
    name: 'Midnight Dream',
    background: 'bg-gradient-to-br from-indigo-600 via-purple-500 to-pink-500',
    textColor: 'text-white',
    preview: 'Deep & Mysterious'
  },
  {
    id: 'solid-1',
    name: 'Midnight',
    background: 'bg-gray-900',
    textColor: 'text-white',
    preview: 'Clean & Professional'
  },
  {
    id: 'solid-2',
    name: 'Snow',
    background: 'bg-gray-50',
    textColor: 'text-gray-900',
    preview: 'Minimal & Clean'
  }
];

export const getThemeById = (themeId: string): ThemeConfig | undefined => {
  return themes.find(theme => theme.id === themeId);
};

export const getThemeClasses = (themeId: string): string => {
  const theme = getThemeById(themeId);
  return theme ? `${theme.background} ${theme.textColor}` : '';
};