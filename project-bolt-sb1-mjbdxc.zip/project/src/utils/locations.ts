export interface Location {
  id: string;
  name: string;
  country: string;
}

export const searchLocations = async (query: string): Promise<Location[]> => {
  // Simulated API call - replace with actual location search API
  const mockLocations: Location[] = [
    { id: '1', name: 'San Francisco', country: 'USA' },
    { id: '2', name: 'San Diego', country: 'USA' },
    { id: '3', name: 'San Jose', country: 'USA' },
    { id: '4', name: 'London', country: 'UK' },
    { id: '5', name: 'Paris', country: 'France' },
    { id: '6', name: 'Tokyo', country: 'Japan' },
  ];

  return mockLocations.filter(loc =>
    loc.name.toLowerCase().includes(query.toLowerCase())
  );
};

export const formatLocation = (location: Location): string => {
  return `${location.name}, ${location.country}`;
};