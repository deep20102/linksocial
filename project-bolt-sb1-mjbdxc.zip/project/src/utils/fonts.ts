export interface FontFamily {
  id: string;
  name: string;
  class: string;
  preview: string;
}

export const fontFamilies: FontFamily[] = [
  { id: 'sans', name: 'Sans', class: 'font-sans', preview: 'Modern & Clean' },
  { id: 'serif', name: 'Serif', class: 'font-serif', preview: 'Classic & Elegant' },
  { id: 'mono', name: 'Mono', class: 'font-mono', preview: 'Monospace Code' },
  { id: 'inter', name: 'Inter', class: 'font-inter', preview: 'Professional' },
  { id: 'poppins', name: 'Poppins', class: 'font-poppins', preview: 'Modern Sans' },
  { id: 'roboto', name: 'Roboto', class: 'font-roboto', preview: 'Clean & Crisp' },
  { id: 'playfair', name: 'Playfair', class: 'font-playfair', preview: 'Elegant Serif' },
  { id: 'montserrat', name: 'Montserrat', class: 'font-montserrat', preview: 'Contemporary' },
  { id: 'lora', name: 'Lora', class: 'font-lora', preview: 'Refined Serif' },
  { id: 'fira', name: 'Fira Code', class: 'font-fira', preview: 'Modern Mono' }
];

export const getFontClass = (fontId: string): string => {
  return fontFamilies.find(font => font.id === fontId)?.class || 'font-sans';
};

export const getTextColorClass = (colorId: string): string => {
  return textColors.find(color => color.id === colorId)?.class || 'text-white';
};