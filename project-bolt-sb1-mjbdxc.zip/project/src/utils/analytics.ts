import { BrowserType, DeviceType } from '../types/analytics';

export const calculateDeviceStats = (totalClicks: number) => ({
  mobile: Math.floor(totalClicks * 0.6),
  desktop: Math.floor(totalClicks * 0.4),
});

export const calculateBrowserStats = (totalClicks: number) => ({
  chrome: Math.floor(totalClicks * 0.5),
  firefox: Math.floor(totalClicks * 0.3),
  safari: Math.floor(totalClicks * 0.2),
});

export const calculateCountryStats = (totalClicks: number) => [
  { name: 'United States', clicks: Math.floor(totalClicks * 0.4) },
  { name: 'United Kingdom', clicks: Math.floor(totalClicks * 0.3) },
  { name: 'Canada', clicks: Math.floor(totalClicks * 0.2) },
  { name: 'Australia', clicks: Math.floor(totalClicks * 0.1) },
];