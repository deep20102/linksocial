export interface TextColor {
  id: string;
  name: string;
  value: string;
  class: string;
}

export const textColors: TextColor[] = [
  { id: 'white', name: 'White', value: '#FFFFFF', class: 'text-white' },
  { id: 'gray-100', name: 'Light Gray', value: '#F3F4F6', class: 'text-gray-100' },
  { id: 'gray-200', name: 'Silver', value: '#E5E7EB', class: 'text-gray-200' },
  { id: 'purple-100', name: 'Light Purple', value: '#EDE9FE', class: 'text-purple-100' },
  { id: 'purple-200', name: 'Lavender', value: '#DDD6FE', class: 'text-purple-200' },
  { id: 'pink-100', name: 'Light Pink', value: '#FCE7F3', class: 'text-pink-100' },
  { id: 'pink-200', name: 'Rose', value: '#FBCFE8', class: 'text-pink-200' },
  { id: 'yellow-100', name: 'Light Yellow', value: '#FEF3C7', class: 'text-yellow-100' },
  { id: 'yellow-200', name: 'Cream', value: '#FDE68A', class: 'text-yellow-200' },
];