import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '../components/forms/Input';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { Check, X } from 'lucide-react';

const signupSchema = z
  .object({
    name: z.string().min(1, 'Name is required'),
    username: z
      .string()
      .min(2, 'Username must have at least 2 characters')
      .max(20, 'Username cannot exceed 20 characters')
      .regex(/^[a-zA-Z0-9._\-']*$/, 'Username can only contain letters, numbers, and . _ - \'')
      .refine((val) => !val.includes(' '), 'Username cannot contain spaces'),
    email: z.string().email('Invalid email address'),
    password: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
      .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
      .regex(/[0-9]/, 'Password must contain at least one number')
      .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character'),
    confirmPassword: z.string(),
    acceptTerms: z.boolean().refine((val) => val === true, 'You must accept the terms and conditions'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ['confirmPassword'],
  });

type SignUpForm = z.infer<typeof signupSchema>;

export function SignUp() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [usernameValue, setUsernameValue] = useState('');
  const [isUsernameAvailable, setIsUsernameAvailable] = useState<boolean | null>(null);
  const [isCheckingUsername, setIsCheckingUsername] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, touchedFields },
    setValue,
    getValues,
  } = useForm<SignUpForm>({
    resolver: zodResolver(signupSchema),
    mode: 'onTouched',
    defaultValues: {
      name: '',
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      acceptTerms: false,
    },
  });

  useEffect(() => {
    const checkUsername = async () => {
      if (usernameValue.length >= 2) {
        setIsCheckingUsername(true);
        try {
          // Simulate API call to check username availability
          await new Promise(resolve => setTimeout(resolve, 500));
          // For demo purposes, let's say usernames containing 'admin' are taken
          setIsUsernameAvailable(!usernameValue.toLowerCase().includes('admin'));
        } catch (error) {
          console.error('Error checking username:', error);
        } finally {
          setIsCheckingUsername(false);
        }
      } else {
        setIsUsernameAvailable(null);
      }
    };

    const debounceTimer = setTimeout(checkUsername, 300);
    return () => clearTimeout(debounceTimer);
  }, [usernameValue]);

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace('@', '');
    if (value.length <= 20) {
      setUsernameValue(value);
      setValue('username', value);
    }
  };

  const onSubmit = async (data: SignUpForm) => {
    try {
      // Simulate API call to check if email exists
      const emailExists = false; // Replace with actual API check
      
      if (emailExists) {
        toast.error('This email address is already registered', {
          duration: 4000,
          position: 'top-center',
        });
        return;
      }

      await login(data.email, data.password);
      toast.success('Account created successfully!');
      navigate('/dashboard');
    } catch (error) {
      toast.error('Failed to create account');
    }
  };

  return (
    <div className="min-h-screen py-16 px-4">
      <div className="max-w-md mx-auto">
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Create Account</h1>
            <p className="text-white/80">Join LinkHub and share your content</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <Input
              name="name"
              placeholder="Full Name"
              register={register}
              error={touchedFields.name ? errors.name?.message : undefined}
            />

            <div className="relative">
              <Input
                name="username"
                placeholder="Username"
                value={usernameValue ? `@${usernameValue}` : ''}
                onChange={handleUsernameChange}
                register={register}
                error={touchedFields.username ? errors.username?.message : undefined}
              />
              {usernameValue.length >= 2 && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center">
                  {isCheckingUsername ? (
                    <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  ) : isUsernameAvailable !== null && (
                    isUsernameAvailable ? (
                      <Check className="w-5 h-5 text-green-400" />
                    ) : (
                      <X className="w-5 h-5 text-red-400" />
                    )
                  )}
                </div>
              )}
            </div>

            <Input
              name="email"
              type="email"
              placeholder="Email address"
              register={register}
              error={touchedFields.email ? errors.email?.message : undefined}
            />

            <Input
              name="password"
              type="password"
              placeholder="Password"
              register={register}
              error={touchedFields.password ? errors.password?.message : undefined}
              showPasswordToggle
            />

            <Input
              name="confirmPassword"
              type="password"
              placeholder="Confirm password"
              register={register}
              error={touchedFields.confirmPassword ? errors.confirmPassword?.message : undefined}
              showPasswordToggle
            />

            <div className="flex items-center">
              <input
                type="checkbox"
                id="acceptTerms"
                {...register('acceptTerms')}
                className="w-4 h-4 rounded border-white/20 bg-white/10 text-purple-600 focus:ring-purple-500"
              />
              <label htmlFor="acceptTerms" className="ml-2 text-sm text-white">
                I accept the{' '}
                <Link to="/terms" className="underline hover:text-purple-200">
                  Terms of Service
                </Link>{' '}
                and{' '}
                <Link to="/privacy" className="underline hover:text-purple-200">
                  Privacy Policy
                </Link>
              </label>
            </div>
            {touchedFields.acceptTerms && errors.acceptTerms && (
              <p className="text-sm text-red-400">{errors.acceptTerms.message}</p>
            )}

            <button
              type="submit"
              className="w-full py-3 px-4 bg-white text-purple-600 rounded-lg font-medium hover:bg-purple-50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-purple-100"
            >
              Create account
            </button>

            <p className="text-center text-white/80">
              Already have an account?{' '}
              <Link to="/login" className="text-white hover:text-purple-200">
                Sign in
              </Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}