import React from 'react';
import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    features: [
      'Up to 5 links',
      'Basic analytics',
      'Custom profile',
      'Mobile-friendly page',
    ],
    cta: 'Get Started',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: '$5',
    period: 'per month',
    features: [
      'Unlimited links',
      'Advanced analytics',
      'Custom themes',
      'Priority support',
      'Remove branding',
      'Custom domains',
    ],
    cta: 'Upgrade to Pro',
    highlighted: true,
  },
];

export function Pricing() {
  return (
    <div className="py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-white mb-4">Simple Pricing</h1>
          <p className="text-xl text-white/80">
            Choose the plan that's right for you
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`rounded-xl p-8 border ${
                plan.highlighted
                  ? 'bg-white text-purple-600 border-transparent'
                  : 'bg-white/10 backdrop-blur-md border-white/20 text-white'
              }`}
            >
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <div className="mb-4">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span className={plan.highlighted ? 'text-purple-400' : 'text-white/60'}>
                  /{plan.period}
                </span>
              </div>
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center space-x-3">
                    <Check className="w-5 h-5 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <button
                className={`w-full btn ${
                  plan.highlighted
                    ? 'bg-purple-600 text-white hover:bg-purple-700'
                    : 'bg-white text-purple-600 hover:bg-pink-100'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-white/80">
            All plans include our core features. Upgrade or downgrade at any time.
          </p>
        </div>
      </div>
    </div>
  );
}