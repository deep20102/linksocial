import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Input } from '../components/forms/Input';
import { useNavigate, Link } from 'react-router-dom';
import toast from 'react-hot-toast';

const emailSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
});

const verificationSchema = z.object({
  code: z.string().length(6, 'Verification code must be 6 digits'),
});

const passwordSchema = z.object({
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number')
    .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type EmailForm = z.infer<typeof emailSchema>;
type VerificationForm = z.infer<typeof verificationSchema>;
type PasswordForm = z.infer<typeof passwordSchema>;

enum Step {
  Email,
  Verification,
  NewPassword,
  Success,
}

export function ForgotPassword() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState<Step>(Step.Email);
  const [email, setEmail] = useState('');
  const [resendTimer, setResendTimer] = useState(0);

  const emailForm = useForm<EmailForm>({
    resolver: zodResolver(emailSchema),
    mode: 'onTouched',
  });

  const verificationForm = useForm<VerificationForm>({
    resolver: zodResolver(verificationSchema),
    mode: 'onTouched',
  });

  const passwordForm = useForm<PasswordForm>({
    resolver: zodResolver(passwordSchema),
    mode: 'onTouched',
  });

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendTimer > 0) {
      timer = setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendTimer]);

  const handleEmailSubmit = async (data: EmailForm) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setEmail(data.email);
      setCurrentStep(Step.Verification);
      setResendTimer(60);
      toast.success('Verification code sent to your email');
    } catch (error) {
      toast.error('Failed to send verification code');
    }
  };

  const handleResendCode = async () => {
    if (resendTimer === 0) {
      try {
        await new Promise(resolve => setTimeout(resolve, 1000));
        setResendTimer(60);
        toast.success('New verification code sent');
      } catch (error) {
        toast.error('Failed to resend code');
      }
    }
  };

  const handleVerificationSubmit = async (data: VerificationForm) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentStep(Step.NewPassword);
    } catch (error) {
      toast.error('Invalid verification code');
    }
  };

  const handlePasswordSubmit = async (data: PasswordForm) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentStep(Step.Success);
      toast.success('Password reset successfully');
      setTimeout(() => {
        navigate('/login');
      }, 2000);
    } catch (error) {
      toast.error('Failed to reset password');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500">
      <div className="py-16 px-4">
        <div className="max-w-md mx-auto">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-white mb-2">Reset Password</h1>
              {currentStep === Step.Email && (
                <p className="text-white/80">Enter your email to reset your password</p>
              )}
            </div>

            {currentStep === Step.Email && (
              <form onSubmit={emailForm.handleSubmit(handleEmailSubmit)} className="space-y-6">
                <Input
                  name="email"
                  type="email"
                  placeholder="Email address"
                  register={emailForm.register}
                  error={emailForm.formState.touchedFields.email ? emailForm.formState.errors.email?.message : undefined}
                />
                <button
                  type="submit"
                  className="w-full btn btn-primary bg-white text-purple-600 hover:bg-pink-100"
                >
                  {emailForm.formState.isSubmitting ? 'Sending...' : 'Send Reset Code'}
                </button>
              </form>
            )}

            {currentStep === Step.Verification && (
              <form onSubmit={verificationForm.handleSubmit(handleVerificationSubmit)} className="space-y-6">
                <p className="text-white/80 text-center mb-4">
                  We've sent a verification code to {email}
                </p>
                <Input
                  name="code"
                  placeholder="Enter 6-digit code"
                  register={verificationForm.register}
                  error={verificationForm.formState.touchedFields.code ? verificationForm.formState.errors.code?.message : undefined}
                />
                <button
                  type="submit"
                  className="w-full btn btn-primary bg-white text-purple-600 hover:bg-pink-100"
                >
                  {verificationForm.formState.isSubmitting ? 'Verifying...' : 'Verify Code'}
                </button>
                <div className="text-center">
                  <button
                    type="button"
                    onClick={handleResendCode}
                    disabled={resendTimer > 0}
                    className="text-white/80 hover:text-white text-sm"
                  >
                    {resendTimer > 0
                      ? `Resend code in ${resendTimer}s`
                      : "Didn't receive code? Send again"}
                  </button>
                </div>
              </form>
            )}

            {currentStep === Step.NewPassword && (
              <form onSubmit={passwordForm.handleSubmit(handlePasswordSubmit)} className="space-y-6">
                <Input
                  name="password"
                  type="password"
                  placeholder="New password"
                  register={passwordForm.register}
                  error={passwordForm.formState.touchedFields.password ? passwordForm.formState.errors.password?.message : undefined}
                  showPasswordToggle
                />
                <Input
                  name="confirmPassword"
                  type="password"
                  placeholder="Confirm new password"
                  register={passwordForm.register}
                  error={passwordForm.formState.touchedFields.confirmPassword ? passwordForm.formState.errors.confirmPassword?.message : undefined}
                  showPasswordToggle
                />
                <button
                  type="submit"
                  className="w-full btn btn-primary bg-white text-purple-600 hover:bg-pink-100"
                >
                  {passwordForm.formState.isSubmitting ? 'Updating...' : 'Update Password'}
                </button>
              </form>
            )}

            {currentStep === Step.Success && (
              <div className="text-center">
                <p className="text-white mb-6">Your password has been reset successfully!</p>
                <p className="text-white/80">Redirecting to login page...</p>
              </div>
            )}

            <div className="mt-6 text-center">
              <Link to="/login" className="text-white hover:text-purple-200">
                Back to Login
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}