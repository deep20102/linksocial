import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ArrowLeft, Lock, Unlock, Trash2 } from 'lucide-react';
import { Input } from '../components/forms/Input';
import { CountrySelector } from '../components/CountrySelector';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useLinks } from '../context/LinkContext';

const linkSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  url: z.string().url('Please enter a valid URL'),
  groupId: z.string().optional(),
  password: z.string().optional(),
});

type LinkForm = z.infer<typeof linkSchema>;

export function AddLink() {
  const navigate = useNavigate();
  const { addLink, groups } = useLinks();
  const [customLogo, setCustomLogo] = useState<File | null>(null);
  const [isPasswordProtected, setIsPasswordProtected] = useState(false);
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [accessMode, setAccessMode] = useState<'allow' | 'block'>('allow');

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LinkForm>({
    resolver: zodResolver(linkSchema),
  });

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCustomLogo(file);
    }
  };

  const removeLogo = () => {
    setCustomLogo(null);
  };

  const toggleCountry = (countryCode: string) => {
    setSelectedCountries(prev =>
      prev.includes(countryCode)
        ? prev.filter(code => code !== countryCode)
        : [...prev, countryCode]
    );
  };

  const onSubmit = async (data: LinkForm) => {
    try {
      await addLink({
        title: data.title,
        url: data.url,
        groupId: data.groupId,
        logo: customLogo,
        password: isPasswordProtected ? data.password : undefined,
        accessControl: {
          mode: accessMode,
          countries: selectedCountries,
        },
      });
      toast.success('Link added successfully!');
      navigate('/dashboard');
    } catch (error) {
      toast.error('Failed to add link');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => navigate('/dashboard')}
          className="mb-6 inline-flex items-center text-white hover:text-purple-200 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Dashboard
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
          <h1 className="text-3xl font-bold text-white mb-8">Add New Link</h1>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <Input
              label="Link Title"
              name="title"
              placeholder="Enter a title for your link"
              register={register}
              error={errors.title?.message}
            />

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Logo (Optional)
              </label>
              <div className="flex items-center space-x-4">
                {customLogo ? (
                  <div className="relative">
                    <img
                      src={URL.createObjectURL(customLogo)}
                      alt="Link logo"
                      className="w-12 h-12 rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={removeLogo}
                      className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full text-white hover:bg-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                  />
                )}
              </div>
            </div>

            <Input
              label="URL"
              name="url"
              placeholder="Enter your link URL"
              register={register}
              error={errors.url?.message}
            />

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Group (Optional)
              </label>
              <select
                {...register('groupId')}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">No group</option>
                {groups.map((group) => (
                  <option key={group.id} value={group.id}>
                    {group.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex items-center space-x-2 mb-2">
                <button
                  type="button"
                  onClick={() => setIsPasswordProtected(!isPasswordProtected)}
                  className="text-white hover:text-purple-200"
                >
                  {isPasswordProtected ? (
                    <Lock className="w-5 h-5" />
                  ) : (
                    <Unlock className="w-5 h-5" />
                  )}
                </button>
                <label className="text-sm font-medium text-white">
                  Password Protection
                </label>
              </div>
              {isPasswordProtected && (
                <Input
                  name="password"
                  type="password"
                  placeholder="Enter password for this link"
                  register={register}
                  error={errors.password?.message}
                  showPasswordToggle
                />
              )}
            </div>

            <CountrySelector
              selectedCountries={selectedCountries}
              onCountryToggle={toggleCountry}
              mode={accessMode}
              onModeChange={setAccessMode}
            />

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50"
              >
                Add Link
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}