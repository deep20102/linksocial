import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  BarChart2, 
  Clock, 
  Globe, 
  Users, 
  Smartphone, 
  Laptop,
  Chrome,
  Monitor,
  MonitorSmartphone
} from 'lucide-react';
import { useLinks } from '../context/LinkContext';
import { StatsCard } from '../components/analytics/StatsCard';
import { 
  calculateDeviceStats, 
  calculateBrowserStats, 
  calculateCountryStats 
} from '../utils/analytics';
import type { AnalyticsData } from '../types/analytics';

const browserIcons = {
  chrome: Chrome,
  firefox: Monitor,
  safari: MonitorSmartphone,
};

export function Analytics() {
  const { id } = useParams<{ id: string }>();
  const { links } = useLinks();
  const link = links.find(l => l.id === id);

  if (!link) {
    return (
      <div className="min-h-screen py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20 text-center">
            <h1 className="text-2xl font-bold text-white mb-4">Link not found</h1>
            <Link
              to="/dashboard"
              className="inline-flex items-center text-white hover:text-purple-200 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const analyticsData: AnalyticsData = {
    totalClicks: link.clicks,
    todayClicks: Math.floor(link.clicks * 0.2),
    averageClicksPerDay: Math.floor(link.clicks / 7),
    devices: calculateDeviceStats(link.clicks),
    browsers: calculateBrowserStats(link.clicks),
    countries: calculateCountryStats(link.clicks),
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Link
            to="/dashboard"
            className="inline-flex items-center text-white hover:text-purple-200 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </Link>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-white mb-2">Analytics for {link.title}</h1>
            <p className="text-white/80">{link.url}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <StatsCard
              title="Total Clicks"
              value={analyticsData.totalClicks}
              Icon={BarChart2}
            />
            <StatsCard
              title="Today's Clicks"
              value={analyticsData.todayClicks}
              Icon={Clock}
            />
            <StatsCard
              title="Average Daily"
              value={analyticsData.averageClicksPerDay}
              Icon={Users}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white/10 rounded-lg p-6">
              <h3 className="text-lg font-medium text-white mb-4">Devices</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Smartphone className="w-5 h-5 text-white/60 mr-2" />
                    <span className="text-white">Mobile</span>
                  </div>
                  <span className="text-white/80">{analyticsData.devices.mobile} clicks</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Laptop className="w-5 h-5 text-white/60 mr-2" />
                    <span className="text-white">Desktop</span>
                  </div>
                  <span className="text-white/80">{analyticsData.devices.desktop} clicks</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 rounded-lg p-6">
              <h3 className="text-lg font-medium text-white mb-4">Browsers</h3>
              <div className="space-y-4">
                {Object.entries(analyticsData.browsers).map(([browser, clicks]) => {
                  const BrowserIcon = browserIcons[browser as keyof typeof browserIcons];
                  return (
                    <div key={browser} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <BrowserIcon className="w-5 h-5 text-white/60 mr-2" />
                        <span className="text-white capitalize">{browser}</span>
                      </div>
                      <span className="text-white/80">{clicks} clicks</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="bg-white/10 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-white">Top Countries</h3>
              <Globe className="w-6 h-6 text-white/60" />
            </div>
            <div className="space-y-4">
              {analyticsData.countries.map((country) => (
                <div key={country.name} className="flex items-center justify-between">
                  <span className="text-white">{country.name}</span>
                  <span className="text-white/80">{country.clicks} clicks</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}