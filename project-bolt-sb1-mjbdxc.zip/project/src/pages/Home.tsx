import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Link as LinkIcon, Palette, BarChart3 } from 'lucide-react';

export function Home() {
  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            One Link for All Your Content
          </h1>
          <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            Create a beautiful landing page to showcase all your important links in one place.
            Customize your page, track analytics, and share your profile with the world.
          </p>
          <Link
            to="/signup"
            className="inline-flex items-center px-8 py-3 bg-white text-purple-600 rounded-lg font-semibold hover:bg-pink-100 transition"
          >
            Get Started <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>

        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4">
              <LinkIcon className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">
              Manage Your Links
            </h3>
            <p className="text-white/80">
              Add, edit, and organize all your important links in one place. Easy to update and always accessible.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <div className="w-12 h-12 bg-pink-500 rounded-lg flex items-center justify-center mb-4">
              <Palette className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">
              Beautiful Themes
            </h3>
            <p className="text-white/80">
              Customize your profile with beautiful themes, colors, and styles to match your brand.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <div className="w-12 h-12 bg-red-500 rounded-lg flex items-center justify-center mb-4">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">
              Detailed Analytics
            </h3>
            <p className="text-white/80">
              Track your link performance with detailed analytics. Know your audience better.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}