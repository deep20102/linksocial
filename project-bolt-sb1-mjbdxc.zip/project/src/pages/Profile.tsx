import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { MapPin } from 'lucide-react';
import { AvatarEditor } from '../components/profile/AvatarEditor';
import { ThemeSelector } from '../components/profile/ThemeSelector';
import { TextStyler } from '../components/profile/TextStyler';
import { ProfileQRCode } from '../components/profile/ProfileQRCode';
import { ProfileHeader } from '../components/profile/ProfileHeader';
import { ProfileFooter } from '../components/profile/ProfileFooter';
import { LocationInput } from '../components/profile/LocationInput';
import { ContactInfoEditor } from '../components/profile/ContactInfo';
import { SecuritySettings } from '../components/profile/SecuritySettings';
import { PrivacySettings } from '../components/profile/PrivacySettings';
import { LinkPreview } from '../components/profile/LinkPreview';
import { useProfileSettings } from '../hooks/useProfileSettings';
import { ProfileSection } from '../components/profile/ProfileSection';
import toast from 'react-hot-toast';

export function Profile() {
  const { username } = useParams<{ username: string }>();
  const {
    avatar,
    theme,
    textStyle,
    location,
    contact,
    privacy,
    links,
    layout,
    updateAvatar,
    updateTheme,
    updateTextStyle,
    updateLocation,
    updateContact,
    updatePrivacy,
    updateLayout,
  } = useProfileSettings();

  const [isEditing, setIsEditing] = useState(false);

  const handleSave = async () => {
    try {
      // Save profile changes
      toast.success('Profile updated successfully');
      setIsEditing(false);
    } catch (error) {
      toast.error('Failed to update profile');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500">
      <ProfileHeader />

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="space-y-8">
          <ProfileSection title="Profile">
            <AvatarEditor
              avatar={avatar}
              shape="circle"
              size={{ width: 150, height: 150 }}
              onShapeChange={(shape) => updateAvatar({ ...avatar, shape })}
              onSizeChange={(size) => updateAvatar({ ...avatar, size })}
              onImageChange={(file) => updateAvatar({ ...avatar, file })}
            />
          </ProfileSection>

          <ProfileSection title="Theme">
            <ThemeSelector
              selectedTheme={theme.id}
              onThemeChange={updateTheme}
              customBackground={theme.background}
              onCustomBackgroundChange={(background) => updateTheme({ ...theme, background })}
              customColor={theme.color}
              onCustomColorChange={(color) => updateTheme({ ...theme, color })}
            />
          </ProfileSection>

          <ProfileSection title="Text Style">
            <TextStyler
              style={textStyle}
              onStyleChange={updateTextStyle}
            />
          </ProfileSection>

          <ProfileSection title="Location">
            <LocationInput
              location={location}
              onLocationChange={updateLocation}
            />
          </ProfileSection>

          <ProfileSection title="Contact Information">
            <ContactInfoEditor
              contact={contact}
              onContactChange={updateContact}
              isPublic={privacy.showContact}
              onVisibilityChange={(showContact) => updatePrivacy({ ...privacy, showContact })}
            />
          </ProfileSection>

          <ProfileSection title="Links">
            <LinkPreview
              links={links}
              layout={layout}
              onLayoutChange={updateLayout}
            />
          </ProfileSection>

          <ProfileSection title="Privacy">
            <PrivacySettings
              settings={privacy}
              onSettingsChange={updatePrivacy}
            />
          </ProfileSection>

          <ProfileSection title="Security">
            <SecuritySettings
              onDeactivate={() => {
                // Handle account deactivation
              }}
              onDelete={() => {
                // Handle account deletion
              }}
            />
          </ProfileSection>

          <ProfileSection title="Share Profile">
            <ProfileQRCode
              username={username || ''}
              qrCodeUrl={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=linkhub.com/@${username}`}
            />
          </ProfileSection>
        </div>

        <div className="mt-8 flex justify-end space-x-4">
          <button
            onClick={() => setIsEditing(false)}
            className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50"
          >
            Save Changes
          </button>
        </div>
      </main>

      <ProfileFooter />
    </div>
  );
}