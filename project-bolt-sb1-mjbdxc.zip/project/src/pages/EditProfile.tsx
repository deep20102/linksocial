import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Camera, Palette, Save } from 'lucide-react';
import { Input } from '../components/forms/Input';

const profileSchema = z.object({
  displayName: z.string().min(2, 'Display name must be at least 2 characters'),
  bio: z.string().max(160, 'Bio must be less than 160 characters'),
  location: z.string().optional(),
  website: z.string().url('Please enter a valid URL').optional().or(z.literal('')),
});

type ProfileForm = z.infer<typeof profileSchema>;

const themes = [
  { id: 'gradient-1', name: 'Purple Sunset', class: 'from-purple-600 via-pink-500 to-red-500' },
  { id: 'gradient-2', name: 'Ocean Breeze', class: 'from-blue-500 via-teal-400 to-emerald-500' },
  { id: 'gradient-3', name: 'Golden Hour', class: 'from-amber-500 via-orange-500 to-red-500' },
];

export function EditProfile() {
  const [selectedTheme, setSelectedTheme] = useState('gradient-1');
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: 'John Doe',
      bio: 'Digital creator & tech enthusiast',
      location: 'San Francisco, CA',
      website: 'https://example.com',
    },
  });

  const onSubmit = async (data: ProfileForm) => {
    try {
      // Here you would typically call an API to update the profile
      console.log('Profile updated:', data);
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };

  return (
    <div className="py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-8">
          <h1 className="text-3xl font-bold text-white mb-8">Edit Profile</h1>

          <div className="mb-8">
            <div className="flex items-center space-x-8">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=faces"
                  alt="Profile"
                  className="w-24 h-24 rounded-full border-4 border-white/20"
                />
                <button className="absolute bottom-0 right-0 bg-purple-600 p-2 rounded-full text-white hover:bg-purple-700 transition">
                  <Camera className="w-4 h-4" />
                </button>
              </div>
              <div>
                <h2 className="text-xl font-semibold text-white mb-1">Profile Photo</h2>
                <p className="text-white/80">Upload a new profile photo</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <Input
              label="Display Name"
              name="displayName"
              register={register}
              error={errors.displayName?.message}
              className="bg-white/5 border-white/10 text-white placeholder-white/50"
            />

            <div className="space-y-1">
              <label className="block text-sm font-medium text-white">Bio</label>
              <textarea
                {...register('bio')}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                rows={3}
              />
              {errors.bio?.message && (
                <p className="text-sm text-red-400">{errors.bio.message}</p>
              )}
            </div>

            <Input
              label="Location"
              name="location"
              register={register}
              error={errors.location?.message}
              className="bg-white/5 border-white/10 text-white placeholder-white/50"
            />

            <Input
              label="Website"
              name="website"
              register={register}
              error={errors.website?.message}
              className="bg-white/5 border-white/10 text-white placeholder-white/50"
            />

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center">
                <Palette className="w-5 h-5 mr-2" />
                Choose Theme
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {themes.map((theme) => (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => setSelectedTheme(theme.id)}
                    className={`h-20 rounded-lg bg-gradient-to-br ${theme.class} p-1 transition ${
                      selectedTheme === theme.id ? 'ring-2 ring-white' : 'opacity-70 hover:opacity-100'
                    }`}
                  >
                    <div className="h-full w-full rounded bg-white/10 backdrop-blur-sm flex items-center justify-center">
                      <span className="text-white font-medium">{theme.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn btn-primary bg-white text-purple-600 hover:bg-pink-100 disabled:opacity-50 inline-flex items-center"
              >
                <Save className="w-4 h-4 mr-2" />
                {isSubmitting ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}