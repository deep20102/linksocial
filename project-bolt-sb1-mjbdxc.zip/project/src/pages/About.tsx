import React from 'react';
import { Users, Globe, Shield } from 'lucide-react';

export function About() {
  return (
    <div className="py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-white mb-4">About LinkHub</h1>
          <p className="text-xl text-white/80">
            Connecting your digital presence in one beautiful place
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <Users className="w-12 h-12 text-white mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">
              Built for Everyone
            </h3>
            <p className="text-white/80">
              Whether you're a creator, professional, or business, LinkHub helps you share what matters.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <Globe className="w-12 h-12 text-white mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">
              Global Reach
            </h3>
            <p className="text-white/80">
              Share your links with anyone, anywhere. One link to connect them all.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <Shield className="w-12 h-12 text-white mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">
              Privacy First
            </h3>
            <p className="text-white/80">
              Your data is always secure. We prioritize your privacy and security.
            </p>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-4">Our Story</h2>
          <p className="text-white/80 mb-4">
            LinkHub was born from a simple idea: make it easy for people to share all their important links in one beautiful place. We believe in the power of connection and making the digital world more accessible.
          </p>
          <p className="text-white/80">
            Today, we're proud to help creators, professionals, and businesses worldwide showcase their digital presence in a way that's uniquely theirs.
          </p>
        </div>
      </div>
    </div>
  );
}