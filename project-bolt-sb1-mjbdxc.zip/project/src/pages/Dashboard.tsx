import React, { useState } from 'react';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { AnimatePresence } from 'framer-motion';
import { Link as LinkIcon, Plus, FolderPlus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SortableLink } from '../components/SortableLink';
import { GroupButton } from '../components/GroupButton';
import { AddGroupForm } from '../components/AddGroupForm';
import { EmptyLinkState } from '../components/EmptyLinkState';
import { EditLinkForm } from '../components/EditLinkForm';
import { useLinks } from '../context/LinkContext';
import toast from 'react-hot-toast';

export function Dashboard() {
  const navigate = useNavigate();
  const { links, groups, removeLink, addGroup, removeGroup, reorderLinks } = useLinks();
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [isAddingGroup, setIsAddingGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const filteredLinks = selectedGroup 
    ? links.filter(link => link.groupId === selectedGroup)
    : links;

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (active && over && active.id !== over.id) {
      const oldIndex = filteredLinks.findIndex((item) => item.id === active.id);
      const newIndex = filteredLinks.findIndex((item) => item.id === over.id);
      
      if (oldIndex !== -1 && newIndex !== -1) {
        const newLinks = arrayMove(filteredLinks, oldIndex, newIndex);
        const updatedLinks = [...links];
        
        filteredLinks.forEach((link, index) => {
          const globalIndex = updatedLinks.findIndex(l => l.id === link.id);
          if (globalIndex !== -1) {
            updatedLinks[globalIndex] = newLinks[index];
          }
        });
        
        reorderLinks(updatedLinks);
      }
    }
  };

  const handleAddGroup = () => {
    if (newGroupName.trim()) {
      addGroup(newGroupName.trim());
      setNewGroupName('');
      setIsAddingGroup(false);
      toast.success('Group created successfully');
    }
  };

  const handleRemoveGroup = (groupId: string) => {
    removeGroup(groupId);
    if (selectedGroup === groupId) {
      setSelectedGroup(null);
    }
    toast.success('Group removed successfully');
  };

  const handleRemoveLink = async (linkId: string) => {
    if (window.confirm('Are you sure you want to delete this link?')) {
      removeLink(linkId);
      toast.success('Link removed successfully');
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4">
        {editingLinkId ? (
          <EditLinkForm
            linkId={editingLinkId}
            onClose={() => setEditingLinkId(null)}
          />
        ) : (
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold text-white">My Links</h1>
              <div className="flex space-x-3">
                <button
                  onClick={() => setIsAddingGroup(true)}
                  className="inline-flex items-center px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
                >
                  <FolderPlus className="w-4 h-4 mr-2" />
                  New Group
                </button>
                <button
                  onClick={() => navigate('/add-link')}
                  className="inline-flex items-center px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50 transition-colors"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Link
                </button>
              </div>
            </div>

            {isAddingGroup && (
              <AddGroupForm
                newGroupName={newGroupName}
                onNameChange={setNewGroupName}
                onAdd={handleAddGroup}
                onCancel={() => setIsAddingGroup(false)}
              />
            )}

            <div className="flex space-x-4 mb-6 overflow-x-auto pb-2">
              <div
                onClick={() => setSelectedGroup(null)}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors cursor-pointer ${
                  selectedGroup === null
                    ? 'bg-white text-purple-600'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                <LinkIcon className="w-4 h-4 mr-2" />
                All Links
              </div>
              {groups.map((group) => (
                <GroupButton
                  key={group.id}
                  id={group.id}
                  name={group.name}
                  isSelected={selectedGroup === group.id}
                  onSelect={() => setSelectedGroup(group.id)}
                  onRemove={() => handleRemoveGroup(group.id)}
                />
              ))}
            </div>

            <DndContext 
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext 
                items={filteredLinks}
                strategy={verticalListSortingStrategy}
              >
                <div className="space-y-3">
                  <AnimatePresence mode="popLayout">
                    {filteredLinks.map((link) => (
                      <SortableLink
                        key={link.id}
                        link={link}
                        onEdit={() => setEditingLinkId(link.id)}
                        onRemove={() => handleRemoveLink(link.id)}
                      />
                    ))}
                  </AnimatePresence>
                </div>
              </SortableContext>
            </DndContext>

            {filteredLinks.length === 0 && <EmptyLinkState />}
          </div>
        )}
      </div>
    </div>
  );
}